module.exports=[27398,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_%5Bid%5D_reset-password_route_actions_e2536e4a.js.map