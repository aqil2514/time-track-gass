var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/[id]/reset-password/route.js")
R.c("server/chunks/[root-of-the-server]__ec266b78._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user_[id]_reset-password_route_actions_e2536e4a.js")
R.m(36350)
module.exports=R.m(36350).exports
