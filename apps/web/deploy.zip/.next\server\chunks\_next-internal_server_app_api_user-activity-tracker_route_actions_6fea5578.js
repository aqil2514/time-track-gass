module.exports=[41779,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user-activity-tracker_route_actions_6fea5578.js.map