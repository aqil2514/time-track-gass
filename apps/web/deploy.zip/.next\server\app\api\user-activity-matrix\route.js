var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-activity-matrix/route.js")
R.c("server/chunks/[root-of-the-server]__d17d70a6._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user-activity-matrix_route_actions_072ff779.js")
R.m(92313)
module.exports=R.m(92313).exports
