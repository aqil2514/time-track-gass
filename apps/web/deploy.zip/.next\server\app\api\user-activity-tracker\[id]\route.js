var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user-activity-tracker/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__b004b369._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user-activity-tracker_[id]_route_actions_34be9845.js")
R.m(45714)
module.exports=R.m(45714).exports
