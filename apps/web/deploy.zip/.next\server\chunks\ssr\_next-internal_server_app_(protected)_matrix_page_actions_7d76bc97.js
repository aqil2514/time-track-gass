module.exports=[53625,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_matrix_page_actions_7d76bc97.js.map