module.exports=[30360,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user-activity-tracker_%5Bid%5D_route_actions_34be9845.js.map