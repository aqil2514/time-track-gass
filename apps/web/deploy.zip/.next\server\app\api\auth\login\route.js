var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__89d7eff7._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_login_route_actions_d02a8f19.js")
R.m(30450)
module.exports=R.m(30450).exports
