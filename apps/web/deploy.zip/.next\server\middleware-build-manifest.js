globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/93dec3919c1dea60.js",
    "static/chunks/652cd53c27924d50.js",
    "static/chunks/aee6c7720838f8a2.js",
    "static/chunks/01bf887ab4501022.js",
    "static/chunks/turbopack-23cf0cd1b9cf443c.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];