var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-daily-insight/route.js")
R.c("server/chunks/[root-of-the-server]__1a621877._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user-daily-insight_route_actions_1d0f29ca.js")
R.m(33001)
module.exports=R.m(33001).exports
