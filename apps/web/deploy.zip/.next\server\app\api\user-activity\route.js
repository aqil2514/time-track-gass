var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-activity/route.js")
R.c("server/chunks/[root-of-the-server]__80768846._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user-activity_route_actions_2736ef19.js")
R.m(91745)
module.exports=R.m(91745).exports
