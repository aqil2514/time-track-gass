var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-daily-percategory/route.js")
R.c("server/chunks/[root-of-the-server]__5643a1d3._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user-daily-percategory_route_actions_f3eb4c81.js")
R.m(33365)
module.exports=R.m(33365).exports
