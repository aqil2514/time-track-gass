module.exports=[60385,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user-activity-matrix_route_actions_072ff779.js.map