var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-activity-tracker/route.js")
R.c("server/chunks/[root-of-the-server]__1aefab9b._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user-activity-tracker_route_actions_6fea5578.js")
R.m(91064)
module.exports=R.m(91064).exports
