module.exports=[27572,a=>{"use strict";var b=a.i(7997);function c({children:a}){return(0,b.jsx)("html",{lang:"en",children:(0,b.jsx)("body",{className:" antialiased bg-slate-900",children:a})})}a.s(["default",()=>c,"metadata",0,{title:{default:"Time Track Supervisor",template:"%s | Time Track Supervisor"}}])}];

//# sourceMappingURL=src_app_layout_tsx_cc8184fa._.js.map