module.exports=[26019,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28protected%29_teams_page_actions_6adf53b6.js.map