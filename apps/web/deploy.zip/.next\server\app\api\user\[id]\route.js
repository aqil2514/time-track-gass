var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__175e5445._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user_[id]_route_actions_c85bf74b.js")
R.m(68662)
module.exports=R.m(68662).exports
