module.exports=[24581,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user-daily-insight_route_actions_1d0f29ca.js.map