module.exports=[13819,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user-daily-percategory_route_actions_f3eb4c81.js.map