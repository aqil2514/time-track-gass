var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user/route.js")
R.c("server/chunks/[root-of-the-server]__f6e85309._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user_route_actions_c34359a8.js")
R.m(4123)
module.exports=R.m(4123).exports
