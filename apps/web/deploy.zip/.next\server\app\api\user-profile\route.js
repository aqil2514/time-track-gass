var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/user-profile/route.js")
R.c("server/chunks/[root-of-the-server]__091127dd._.js")
R.c("server/chunks/[root-of-the-server]__d396bed4._.js")
R.c("server/chunks/_24e06efd._.js")
R.c("server/chunks/[root-of-the-server]__caaf520f._.js")
R.c("server/chunks/_next-internal_server_app_api_user-profile_route_actions_4f8d7c44.js")
R.m(17426)
module.exports=R.m(17426).exports
